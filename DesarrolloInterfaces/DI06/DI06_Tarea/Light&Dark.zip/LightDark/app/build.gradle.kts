plugins {
    id("org.jetbrains.dokka") version "1.9.10"
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

subprojects {
    apply(plugin = "org.jetbrains.dokka")
}

android {
    namespace = "com.example.lightdark"
    compileSdk {
        version = release(36)
    }

    defaultConfig {
        applicationId = "com.example.lightdark"
        minSdk = 28
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    implementation("androidx.preference:preference-ktx:1.2.1")
    dokkaPlugin("org.jetbrains.dokka:android-documentation-plugin:1.9.10")
}