package com.example.lightdark.settings

import android.os.Bundle

import androidx.preference.Preference

import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.motion.widget.Key
import androidx.preference.PreferenceFragmentCompat
import com.example.lightdark.R

/**
 * Fragment que muestra la pantalla de preferencias de la aplicación.
 *
 * Carga el menú de ajustes desde un recurso XML y gestiona los cambios
 * de preferencia en tiempo real, como el cambio de tema visual (claro/oscuro/sistema).
 *
 * Se utiliza dentro de [SettingsActivity] para mostrar las opciones configurables.
 *
 * @author Eugen Moga
 */
class SettingsFragment : PreferenceFragmentCompat() {

    /**
     * Inicializa las preferencias desde el recurso XML y registra los listeners
     * de cambio para aplicar el nuevo tema de forma inmediata.
     *
     * Cuando el usuario selecciona un nuevo tema, llama a [ThemeSetup.applyTheme]
     * para aplicarlo sin necesidad de reiniciar la aplicación.
     *
     * @param savedInstanceState Estado previo del fragment, o null si es nuevo.
     * @param rootKey Clave de la preferencia raíz desde la que se carga el árbol,
     *                o null para cargar todas las preferencias.
     */
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.menu_settings, rootKey)

        // Se comprueba el tema guardado como predeterminado
        findPreference<Preference>(getString(R.string.settings_theme_key))
            ?.setOnPreferenceChangeListener{_, newValue ->
            if (newValue is String){
                ThemeSetup.applyTheme(newValue, requireContext())
                true
            } else {
                false
            }
        }
    }
}