package com.example.lightdark.settings

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager

/**
 * Objeto singleton encargado de gestionar y aplicar el tema visual de la aplicación.
 *
 * Lee la preferencia guardada por el usuario y configura el modo noche
 * de Android en consecuencia (claro, oscuro o según el sistema).
 *
 * @property DARK_THEME  Valor de preferencia que activa el modo oscuro.
 * @property LIGHT_THEME Valor de preferencia que activa el modo claro.
 * @property DEFAULT_THEME Valor de preferencia que sigue el tema del sistema.
 *
 * @author EugenMoga
 */
object ThemeSetup {
    const val DARK_THEME = "Oscuro"
    const val LIGHT_THEME = "Claro"
    const val DEFAULT_THEME = "Predeterminado"

    /**
     * Aplica el tema de la aplicación según el valor de preferencia recibido.
     *
     * @param selectedTheme Nombre del tema seleccionado: [DARK_THEME], [LIGHT_THEME]
     *                      o cualquier otro valor para usar el tema del sistema.
     * @param context       Contexto de la aplicación o actividad.
     */
    fun applyTheme(selectedTheme: String?, context: Context) {
        when (selectedTheme) {
            DARK_THEME  -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            LIGHT_THEME -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            else        -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    /**
     * Lee la preferencia de tema almacenada y aplica el modo correspondiente.
     *
     * Usa [PreferenceManager.getDefaultSharedPreferences] para obtener el valor
     * guardado bajo la clave `"theme"`. Si no existe ninguna preferencia,
     * aplica el tema [DEFAULT_THEME] (sigue al sistema).
     *
     * @param context Contexto de la aplicación o actividad desde donde se llama.
     */
    fun applyTheme(context: Context) {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        val selectedTheme = sharedPreferences.getString("theme", DEFAULT_THEME)
        applyTheme(selectedTheme, context)
    }
}