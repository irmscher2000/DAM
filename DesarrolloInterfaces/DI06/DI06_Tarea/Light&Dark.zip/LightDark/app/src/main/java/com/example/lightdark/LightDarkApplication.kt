package com.example.lightdark

import android.app.Application
import com.example.lightdark.settings.ThemeSetup

/**
 * Clase de aplicación personalizada para LightDark.
 *
 * Se ejecuta al iniciar la app antes que cualquier Activity.
 * Su función principal es aplicar el tema guardado por el usuario
 * (claro, oscuro o predeterminado del sistema) de forma global.
 *
 * @author Eugen Moga
 */
class LightDarkApplication : Application() {

    /**
     * Punto de entrada de la aplicación.
     * Aplica el tema seleccionado por el usuario antes de que se cree ninguna pantalla.
     */
    override fun onCreate() {
        super.onCreate()
        ThemeSetup.applyTheme(this)
    }
}