package com.example.lightdark

import android.os.Bundle
import android.text.TextUtils
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.lightdark.settings.SettingsActivity
import com.example.lightdark.settings.ThemeSetup
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/**
 * Actividad principal de la aplicación LightDark.
 *
 * Gestiona la pantalla de inicio con un formulario de email,
 * una barra de herramientas superior y una barra inferior con acciones.
 * También permite la navegación hacia los ajustes de tema (claro/oscuro).
 *
 * @author Eugen Moga
 */
class MainActivity : AppCompatActivity() {

    /** Campo de texto donde el usuario introduce su dirección de email. */
    private lateinit var editTextEmail: TextInputEditText

    /** Contenedor del campo de email que muestra mensajes de error de validación. */
    private lateinit var textInputEmail: TextInputLayout

    /**
     * Inicializa la actividad: aplica el tema guardado, infla el layout,
     * configura las barras de herramientas y los listeners de insets.
     *
     * @param savedInstanceState Estado previo de la actividad, o null si es nueva.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSetup.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        editTextEmail = findViewById(R.id.editTextEmail)
        textInputEmail = findViewById(R.id.text_input_layout_email)

        // Se infla el menu para mostrar los iconos para buscar y compartir
        val bottomAppBar = findViewById<com.google.android.material.bottomappbar.BottomAppBar>(R.id.bottomBar)
        bottomAppBar.replaceMenu(R.menu.bottom_app_bar_menu)

        enableEdgeToEdge()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

    }

    /**
     * Infla el menú de la barra de herramientas superior.
     *
     * @param menu El menú en el que se inflan los ítems.
     * @return true para que el menú sea visible.
     */
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    /**
     * Gestiona la selección de ítems del menú superior.
     * Navega hacia la pantalla de ajustes al pulsar cualquier ítem.
     *
     * @param item El ítem del menú seleccionado por el usuario.
     * @return true indicando que el evento ha sido consumido.
     */
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        SettingsActivity.start(this)
        return true
    }

    /**
     * Valida el campo de email del formulario.
     * Muestra un mensaje de error si el campo está vacío,
     * o lo limpia si contiene algún valor.
     *
     * @param view La vista que dispara la acción (botón de validar).
     */
    fun validateEmailField(view: View){
        if (TextUtils.isEmpty(editTextEmail.text)){
            textInputEmail.error = "Este campo es obligatorio"
            textInputEmail.isErrorEnabled = true
        } else {
            textInputEmail.error = null
            textInputEmail.isErrorEnabled = false
        }
    }
}