package com.example.lightdark.settings

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.lightdark.R

/**
 * Actividad que muestra la pantalla de ajustes de la aplicación.
 *
 * Permite al usuario configurar preferencias como el tema visual (claro/oscuro).
 * Aplica el tema guardado antes de inflar el layout para evitar parpadeos visuales.
 * Incluye una barra de herramientas con botón de retroceso hacia [MainActivity].
 *
 * @author Eugen Moga
 */
class SettingsActivity : AppCompatActivity() {
    /**
     * Inicializa la pantalla de ajustes: aplica el tema, configura el layout
     * y habilita el botón de navegación hacia atrás en la toolbar.
     *
     * @param savedInstanceState Estado previo de la actividad, o null si es nueva.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSetup.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)


        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    companion object{
        /**
         * Lanza la actividad de ajustes desde cualquier contexto de la aplicación.
         *
         * Metodo de fábrica estático que encapsula la creación del [Intent],
         * evitando que otras clases dependan directamente del nombre de esta actividad.
         *
         * @param context Contexto desde el que se inicia la actividad.
         */
        fun start(context: Context){
            val intent = Intent(context, SettingsActivity::class.java)
            context.startActivity(intent)
        }
    }
}